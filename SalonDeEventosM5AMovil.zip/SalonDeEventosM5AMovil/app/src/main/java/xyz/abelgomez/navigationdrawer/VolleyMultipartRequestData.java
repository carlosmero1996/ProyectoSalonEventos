package xyz.abelgomez.navigationdrawer;

public class VolleyMultipartRequestData {
    private String content;

    public VolleyMultipartRequestData(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }
}
