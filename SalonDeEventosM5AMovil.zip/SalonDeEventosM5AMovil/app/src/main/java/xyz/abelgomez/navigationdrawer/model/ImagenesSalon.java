package xyz.abelgomez.navigationdrawer.model;

import java.io.Serializable;

public class ImagenesSalon implements Serializable {



    private int imgSalId;


    private String imgSalNombre;


    private String imgSalUrl;

   // private Salon salon;
}
