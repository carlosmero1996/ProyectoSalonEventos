import { Component } from '@angular/core';

@Component({
  selector: 'app-headerlogeo',
  templateUrl: './headerlogeo.component.html',
  styleUrls: ['./headerlogeo.component.css']
})
export class HeaderlogeoComponent {

}
