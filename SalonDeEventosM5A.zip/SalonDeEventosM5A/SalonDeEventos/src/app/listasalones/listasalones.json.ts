import { Salon } from "../modelo/salon";
import { SalonComponent } from "../salon/salon.component";

export const SALONES: SalonComponent[] = [


];