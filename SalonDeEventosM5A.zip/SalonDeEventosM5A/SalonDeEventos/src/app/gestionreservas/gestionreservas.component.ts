import { Component } from '@angular/core';

@Component({
  selector: 'app-gestionreservas',
  templateUrl: './gestionreservas.component.html',
  styleUrls: ['./gestionreservas.component.css']
})
export class GestionreservasComponent {

}
