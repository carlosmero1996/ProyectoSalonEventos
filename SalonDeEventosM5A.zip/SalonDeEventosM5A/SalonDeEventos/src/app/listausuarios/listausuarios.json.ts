import { Persona } from "../modelo/persona";


export const PERSONAS: Persona[]= [

    {perId: 1, perCedula: '0106434665', perNombre: 'Daniel', perApellido: 'Andrade', perCorreo: 'asd@gmail.com', perDireccion: '13 de Abril', perFechaNacimiento: new Date('2023-01-01'), perTelefono: '0978127584' }
];