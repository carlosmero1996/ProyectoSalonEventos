import { Component } from '@angular/core';

@Component({
  selector: 'app-usuariogestion',
  templateUrl: './usuariogestion.component.html',
  styleUrls: ['./usuariogestion.component.css']
})
export class UsuariogestionComponent {

}
