import { Component } from '@angular/core';

@Component({
  selector: 'app-gestioncotizaciones',
  templateUrl: './gestioncotizaciones.component.html',
  styleUrls: ['./gestioncotizaciones.component.css']
})
export class GestioncotizacionesComponent {

}
