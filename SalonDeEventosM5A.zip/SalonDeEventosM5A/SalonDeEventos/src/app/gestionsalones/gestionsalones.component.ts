import { Component } from '@angular/core';

@Component({
  selector: 'app-gestionsalones',
  templateUrl: './gestionsalones.component.html',
  styleUrls: ['./gestionsalones.component.css']
})
export class GestionsalonesComponent {

}
